# 5 Scores in range 0 up 10 (Float)
#Find Highest to lowest
# if score <0 or >10, re-enter (Validate)
#use Y or y in your condition
counter = 0
answer = 'y'
overallaverge = 0
finalaverage = 0
while answer == 'y' or answer == 'Y': 
total = 0
highest = 0 #Start with the lowest and go up
lowest = 10 #Start with the highest and go down
for s in range(5):
  score = float(input("Enter a value"))
  while score < 0 or score > 10:
    print "Invalid Score"
    score = float(input('Enter a value'))
  #Step 2: Average without the highest & lowest
  #You need a total
  #Once you get the total, Subtract the highest from the low then divide by 3 to get the Average.if score > highest:
    highest = score
  if score < lowest:
    lowest = score 
    #Accumulate total
  total += score
  print highest , lowest
  #Calculate average
  average = (total - highest - lowest)/3
  overallaverage += average #accumulates
  print average
  counter = counter + 1
  answer = input('Do you have more entries')
finalaverage = overallaverage/counter
print 'There were ' , counter, 'entries'
#Part 3: Add a counter, each while add 1
# add a while loop to check if the user has more entrees
